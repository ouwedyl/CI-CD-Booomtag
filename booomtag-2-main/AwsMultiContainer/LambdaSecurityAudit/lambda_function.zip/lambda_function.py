import boto3
import json
import os
import logging
from botocore.config import Config
from botocore.exceptions import ClientError, ReadTimeoutError, ConnectTimeoutError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Config met timeouts
aws_config = Config(connect_timeout=5, read_timeout=10)

# Clients met timeout
s3 = boto3.client('s3', config=aws_config)
iam = boto3.client('iam', config=aws_config)

ACCOUNT_ID = os.environ.get("ACCOUNT_ID")

def check_public_buckets():
    findings = []
    try:
        buckets = s3.list_buckets()['Buckets']
    except (ClientError, ReadTimeoutError, ConnectTimeoutError) as e:
        logger.error("Fout bij ophalen van S3 buckets: %s", e)
        return findings

    for bucket in buckets:
        name = bucket['Name']
        try:
            acl = s3.get_bucket_acl(Bucket=name, ExpectedBucketOwner=ACCOUNT_ID)
        except ClientError as e:
            logger.error("Fout bij ophalen ACL voor bucket %s: %s", name, e)
            continue

        for grant in acl['Grants']:
            grantee = grant.get('Grantee', {})
            if grantee.get('URI') == "http://acs.amazonaws.com/groups/global/AllUsers":
                findings.append("S3 bucket '%s' is PUBLIC" % name)
    return findings

def check_iam_policies():
    findings = []
    try:
        roles = iam.list_roles()['Roles']
    except (ClientError, ReadTimeoutError, ConnectTimeoutError) as e:
        logger.error("Fout bij ophalen IAM roles: %s", e)
        return findings

    for role in roles:
        role_name = role['RoleName']
        try:
            policies = iam.list_role_policies(RoleName=role_name)['PolicyNames']
        except ClientError as e:
            logger.error("Fout bij ophalen IAM policies voor role %s: %s", role_name, e)
            continue

        for policy in policies:
            try:
                document = iam.get_role_policy(RoleName=role_name, PolicyName=policy)['PolicyDocument']
            except ClientError as e:
                logger.error("Fout bij ophalen IAM policy document %s: %s", policy, e)
                continue

            for stmt in document.get('Statement', []):
                if stmt.get('Action') == "*" or stmt.get('Resource') == "*":
                    findings.append("IAM role '%s' heeft wildcard permissions." % role_name)
    return findings

def check_env_secrets():
    findings = []
    for key, value in os.environ.items():
        if any(s in key.lower() for s in ["secret", "key", "password"]):
            findings.append("Environment variable '%s' may contain a secret." % key)
    return findings

def lambda_handler(event, context):
    logger.info("Starting Security Audit Lambda...")

    results = {
        "public_buckets": check_public_buckets(),
        "iam_issues": check_iam_policies(),
        "env_secrets": check_env_secrets()
    }

    summary = json.dumps(results, indent=4)
    logger.info("Security Audit Results:\n%s", summary)

    bucket_name = os.environ.get("RESULT_BUCKET")
    if bucket_name:
        try:
            s3.put_object(
                Bucket=bucket_name,
                Key="security_audit_result.json",
                Body=summary.encode("utf-8"),
                ExpectedBucketOwner=ACCOUNT_ID
            )
            logger.info("Audit report saved in S3 bucket '%s'", bucket_name)
        except ClientError as e:
            logger.error("Fout bij opslaan audit report in S3: %s", e)

    return {"statusCode": 200, "body": summary}
